import SwiftUI

// MARK: - Colors

extension Color {
    // Surfaces
    static let bmuxSurface         = Color(hex: "#111111") // outermost background
    static let bmuxRail            = Color(hex: "#191919") // workspace rail
    static let bmuxCard            = Color(hex: "#1c1c1c") // unselected card
    static let bmuxCardBorder      = Color(hex: "#252525")
    static let bmuxCardSelected    = Color(hex: "#232e22") // muted green
    static let bmuxCardSelectedBorder = Color(hex: "#3a4e38")
    static let bmuxSeparator       = Color(hex: "#1d1d1d")
    static let bmuxSeparatorSubtle = Color(hex: "#242424")
    static let bmuxUserMessage     = Color(hex: "#1e1e1e")
    static let bmuxActionRow       = Color(hex: "#171717")
    static let bmuxActionRowBorder = Color(hex: "#222222")
    static let bmuxComposer        = Color(hex: "#181818")
    static let bmuxComposerBorder  = Color(hex: "#2a2a2a")
    static let bmuxPillActive      = Color(hex: "#252525")

    // Text
    static let bmuxTextPrimary     = Color(hex: "#e8e8e8")
    static let bmuxTextSecondary   = Color(hex: "#bbbbbb")
    static let bmuxTextTertiary    = Color(hex: "#888888")
    static let bmuxTextMuted       = Color(hex: "#555555")
    static let bmuxTextDisabled    = Color(hex: "#444444")

    // Accents
    static let bmuxAccentGreen     = Color(hex: "#6a9e5e") // merged, checks
    static let bmuxAccentYellow    = Color(hex: "#9e9e6a") // working/activity
    static let bmuxTurnAccent      = Color(hex: "#4a6642") // left border on current turn
    static let bmuxLinkGreen       = Color(hex: "#7a9e6a") // inline links
    static let bmuxTabUnderline    = Color(hex: "#e0e0e0")

    // Amber notice
    static let bmuxAmberFill       = Color(hex: "#231c0a")
    static let bmuxAmberBorder     = Color(hex: "#3d2e0a")
    static let bmuxAmberText       = Color(hex: "#c8a44a")

    // Queue button
    static let bmuxQueueFill       = Color(hex: "#1e2e1c")
    static let bmuxQueueBorder     = Color(hex: "#2e4a2a")
    static let bmuxQueueText       = Color(hex: "#7ab86a")

    // Hex initializer
    init(hex: String) {
        let h = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        var rgb: UInt64 = 0
        Scanner(string: h).scanHexInt64(&rgb)
        self.init(
            red:   Double((rgb >> 16) & 0xFF) / 255,
            green: Double((rgb >> 8)  & 0xFF) / 255,
            blue:  Double( rgb        & 0xFF) / 255
        )
    }
}

// MARK: - Typography

struct BmuxFont {
    // Use SF Pro as the system-native substitute for the reference's geometric sans.
    // If Inter is required, embed the font files and replace `.system` calls.

    static let brandMark        = Font.system(size: 16, weight: .bold,    design: .default)
    static let workspaceHeading = Font.system(size: 10.5, weight: .medium, design: .default)
    static let cardRepo         = Font.system(size: 11,   weight: .regular, design: .default)
    static let cardTitle        = Font.system(size: 14,   weight: .semibold, design: .default)
    static let cardStatus       = Font.system(size: 12,   weight: .regular, design: .default)
    static let cardLink         = Font.system(size: 11.5, weight: .regular, design: .default)
    static let contentEyebrow   = Font.system(size: 12,   weight: .regular, design: .default)
    static let contentTitle     = Font.system(size: 26,   weight: .bold,    design: .default)
    static let contentSubtitle  = Font.system(size: 13.5, weight: .regular, design: .default)
    static let tabLabel         = Font.system(size: 13.5, weight: .regular, design: .default)
    static let tabLabelActive   = Font.system(size: 13.5, weight: .medium,  design: .default)
    static let secondaryNav     = Font.system(size: 13,   weight: .medium,  design: .default)
    static let turnEyebrow      = Font.system(size: 10,   weight: .medium,  design: .default)
    static let turnHeadline     = Font.system(size: 18,   weight: .bold,    design: .default)
    static let turnBody         = Font.system(size: 13.5, weight: .regular, design: .default)
    static let disclosureLabel  = Font.system(size: 13.5, weight: .regular, design: .default)
    static let previousTurnLabel = Font.system(size: 13.5, weight: .regular, design: .default)
    static let previousTurnMeta = Font.system(size: 11.5, weight: .regular, design: .default)
    static let authorLabel      = Font.system(size: 13,   weight: .semibold, design: .default)
    static let conversationTime = Font.system(size: 12,   weight: .regular, design: .default)
    static let conversationBody = Font.system(size: 13.5, weight: .regular, design: .default)
    static let actionRowLabel   = Font.system(size: 13,   weight: .regular, design: .default)
    static let actionRowStatus  = Font.system(size: 12,   weight: .regular, design: .default)
    static let workingStatus    = Font.system(size: 12.5, weight: .regular, design: .default)
    static let composerInput    = Font.system(size: 13.5, weight: .regular, design: .default)
    static let composerMeta     = Font.system(size: 12,   weight: .regular, design: .default)
    static let queueButton      = Font.system(size: 13,   weight: .medium,  design: .default)
    static let footer           = Font.system(size: 11.5, weight: .regular, design: .default)
}

// MARK: - Spacing

struct BmuxSpacing {
    static let railWidth: CGFloat       = 340
    static let railPaddingH: CGFloat    = 12
    static let railPaddingV: CGFloat    = 16
    static let railCardGap: CGFloat     = 8
    static let cardPaddingH: CGFloat    = 12
    static let cardPaddingV: CGFloat    = 12
    static let cardInternalGap: CGFloat = 6
    static let cardLinkGap: CGFloat     = 4
    static let contentPaddingH: CGFloat = 24
    static let contentPaddingV: CGFloat = 20
    static let headerToTabs: CGFloat    = 16
    static let tabsToBody: CGFloat      = 20
    static let turnBorderWidth: CGFloat = 2
    static let turnPaddingLeft: CGFloat = 16
    static let disclosureRowV: CGFloat  = 14
    static let previousTurnV: CGFloat   = 12
    static let composerPaddingH: CGFloat = 12
    static let composerPaddingV: CGFloat = 10
    static let actionRowPaddingH: CGFloat = 12
    static let actionRowPaddingV: CGFloat = 8
}

// MARK: - Radius

struct BmuxRadius {
    static let appShell: CGFloat    = 12
    static let card: CGFloat        = 8
    static let pill: CGFloat        = 6
    static let actionRow: CGFloat   = 6
    static let composer: CGFloat    = 8
    static let amberNotice: CGFloat = 6
    static let queueButton: CGFloat = 6
}
