# Codex Start Here

This package contains the complete design handoff for the **bmux** macOS SwiftUI UI. Two reference screenshots establish the approved visual targets. All measurements, tokens, and fixtures below are derived from those screenshots.

---

## Artifact inventory

| File | Purpose |
|---|---|
| `design-tokens.json` | Machine-readable tokens: colors, typography, spacing, radii, borders, icons |
| `BmuxDesignTokens.swift` | Drop-in Swift declarations — Color extensions, BmuxFont, BmuxSpacing, BmuxRadius |
| `reference-fixtures.json` | Deterministic view-model data for both reference screens |
| `SWIFTUI-IMPLEMENTATION.md` | Per-component layout spec, measurement notes, behavior table |
| `CODEX-START-HERE.md` | This file |

**Reference screenshots** (in the repo root or alongside this file):
- **Reference A** — Session tab / Overview selected
- **Reference B** — Terminal tab / conversation view

---

## Authority order

1. Reference screenshots — ground truth for layout, color, and hierarchy
2. `design-tokens.json` — measured values; prefer these over eyeballing the PNG
3. `BmuxDesignTokens.swift` — wire directly into SwiftUI; do not duplicate constants
4. `reference-fixtures.json` — seed views during development; replace with live API data
5. `SWIFTUI-IMPLEMENTATION.md` — component ownership, spacing, and behavior notes

---

## Integration instructions

### 1. Drop in tokens

Copy `BmuxDesignTokens.swift` into your Xcode project. It defines `Color` extensions and three structs (`BmuxFont`, `BmuxSpacing`, `BmuxRadius`). Use them everywhere instead of raw hex literals or magic numbers.

### 2. View tree

```
BmuxAppShell
├── BmuxBrandHeader
└── HSplitView
    ├── BmuxWorkspaceRail          (fixed width: BmuxSpacing.railWidth = 340pt)
    │   └── BmuxWorkspaceCard ×N  (selected / unselected state)
    └── BmuxContentPane
        ├── BmuxWorkspaceHeader    (eyebrow, title, subtitle)
        ├── BmuxPrimaryTabs        (Session | Terminal | Native)
        └── TabContent
            ├── BmuxSessionView
            │   ├── BmuxSecondaryTabs   (Overview | Related work | Findings)
            │   ├── BmuxCurrentTurn
            │   ├── BmuxOverlapNotice
            │   ├── BmuxDisclosureRow ×3
            │   └── BmuxPreviousTurns
            └── BmuxTerminalView
                ├── BmuxUserMessage
                ├── BmuxAssistantMessage
                │   └── BmuxActionRow ×N
                ├── BmuxRunStatus
                └── BmuxFollowUpComposer
```

### 3. Wire fixtures

Import `reference-fixtures.json` as a local JSON asset, decode into Swift models, and inject via `@StateObject` or environment. Replace with live API calls once the layout matches the references.

### 4. Locate existing components

Historical names worth searching before creating new files:
- `ContentView.swift`
- `AgentSessionFactualProjectionModeHost`
- `AgentSessionWorkspaceHeader`
- `AgentSessionFactualProjectionTurnDetailView`
- `AgentSessionFactualProjectionPriorTurnCardView`

Integrate shared tokens and layout into whatever is mounted there; do not create a disconnected showcase view as the production implementation.

### 5. Validation loop

For each component:
1. Render with fixture data
2. Screenshot at 2x
3. Overlay against the matching reference region at identical scale
4. Measure residual errors in color (ΔE) and geometry (pt)
5. Fix discrepancies → re-screenshot → repeat
6. Confirm ordinary live-data routes work after fixtures are replaced

---

## Key layout constraints

| Constraint | Value | Source |
|---|---|---|
| Rail width | 340pt | measured |
| App shell corner radius | 12pt | measured |
| Card corner radius | 8pt | measured |
| Card border width | 1pt | measured |
| Turn accent left border | 2pt | measured |
| Tab underline height | 2pt | measured |
| Content horizontal padding | 24pt | measured |
| Content vertical padding | 20pt | measured |

## Color sampling notes

- All hex values sampled from pixels away from text antialiasing and near-border gradients.
- `bmuxCardSelected` (#232e22) is a dark desaturated green — not a strong hue. Do not substitute with a system green.
- `bmuxAmberFill` (#231c0a) is very dark — nearly invisible as a fill without its border.
- The tab underline is text-width, not stretched to the tab cell width.

## Typography notes

- Font identified by visual match as a geometric sans-serif (likely Inter or similar). **Use SF Pro Text / SF Pro Display** as the system-native substitute. This avoids bundling third-party fonts and matches macOS conventions.
- `turnEyebrow` and `workspaceHeading` use uppercase + letter-spacing; apply `.textCase(.uppercase)` and `.kerning(1.2)` / `.kerning(1.4)`.
- Line heights in SwiftUI: use `.lineSpacing()` to approximate — `turnBody` targets ~1.55× leading, `cardLink` ~1.4×.

## Behaviors

| Interaction | Behavior |
|---|---|
| Tap workspace card | Selects card (muted green fill/border), updates content pane |
| Tap resource link inside card | Opens link; must not be swallowed by card selection gesture |
| Tap primary tab | Switches Session / Terminal / Native content |
| Tap secondary tab (Overview etc.) | Switches sub-view within Session |
| Tap disclosure row + | Expands row (state not shown in reference; treat as inferred) |
| Tap previous turn + | Expands turn detail (state not shown; inferred) |
| Tap Stop | Cancels current agent run (wire to your API) |
| Tap Queue message | Sends composer text to agent queue (wire to your API) |
| Tap Inspect overlap | Opens overlap detail (wire to your navigation) |
| Tap View source | Opens source attribution (wire to your navigation) |
| Tap Session overview ↗ | Navigates to session overview from Terminal tab |

## Outstanding items

- [ ] Actual PostScript font name unconfirmed — verify in Figma source if available
- [ ] Disclosure row expanded state not shown in references — design as proposed
- [ ] Native tab content not shown — implement as a stub until designed
- [ ] Scroll ownership: whether headers/composers are sticky is inferred, not confirmed from screenshots
- [ ] Token counts in previous turns are null in reference — confirm API field name
- [ ] Black image margin and circular down-arrow in screenshot are presumed capture artifacts — do not implement as app controls
