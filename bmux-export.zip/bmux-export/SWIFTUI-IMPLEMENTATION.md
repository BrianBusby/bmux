# SwiftUI Implementation Specification

Measured from Reference A (Session/Overview) and Reference B (Terminal/conversation).  
Pixel-to-point mapping: 1:1 logical coordinates (retina scale unconfirmed; treat as 1x design units).

---

## BmuxAppShell

```swift
// Outer rounded rectangle on a dark background
ZStack {
    Color.bmuxSurface.ignoresSafeArea()
    VStack(spacing: 0) {
        BmuxBrandHeader()
        HSplitView {
            BmuxWorkspaceRail()
                .frame(width: BmuxSpacing.railWidth)
            BmuxContentPane()
        }
    }
    .clipShape(RoundedRectangle(cornerRadius: BmuxRadius.appShell))
    .overlay(RoundedRectangle(cornerRadius: BmuxRadius.appShell).stroke(Color.bmuxSeparator, lineWidth: 1))
}
```

---

## BmuxBrandHeader

- Height: ~44pt (measured)
- HStack: leading group (bmux mark + CompanyCam label), trailing label
- Divider at bottom: 1pt, `bmuxSeparator`
- bmux mark: bold 16pt + sparkle SF Symbol at 13pt
- "CompanyCam": 13pt, `bmuxTextMuted`
- "Design concept · illustrative data": 12pt, `bmuxTextDisabled` — remove or hide in production

---

## BmuxWorkspaceRail

- Background: `bmuxRail`
- Fixed width: `BmuxSpacing.railWidth` (340pt)
- Right border: 1pt, `bmuxSeparator`
- Padding: H 12pt, V 16pt
- WORKSPACES heading: 10.5pt uppercase, tracking 1.2, `bmuxTextMuted`
- Count label: 11pt, `bmuxTextDisabled`
- Card stack: `VStack(spacing: BmuxSpacing.railCardGap)` inside a `ScrollView`

---

## BmuxWorkspaceCard

### Layout

```swift
VStack(alignment: .leading, spacing: 0) {
    Text(repo)          // cardRepo font, bmuxTextMuted
    Text(title)         // cardTitle font, bmuxTextSecondary, lineLimit(nil)
    StatusRow()         // icon + label, 12pt
    Divider()           // bmuxSeparatorSubtle
    ForEach(links) { ResourceLinkRow($0) }
    if let owner { OwnerRow(owner) }
}
.padding(.horizontal, BmuxSpacing.cardPaddingH)
.padding(.vertical, BmuxSpacing.cardPaddingV)
.background(selected ? Color.bmuxCardSelected : Color.bmuxCard)
.clipShape(RoundedRectangle(cornerRadius: BmuxRadius.card))
.overlay(
    RoundedRectangle(cornerRadius: BmuxRadius.card)
        .stroke(selected ? Color.bmuxCardSelectedBorder : Color.bmuxCardBorder, lineWidth: 1)
)
```

### Internal spacing
- repo → title: 2pt
- title → status: 6pt
- status → divider: 8pt
- divider → links: 8pt
- links VStack spacing: 4pt
- links → owner: 8pt

### ResourceLinkRow
- HStack(alignment: .top, spacing: 6)
- Leading SF Symbol (see `icon.sfSymbolAlternatives` in tokens), 12pt, `bmuxTextMuted`
- Text: 11.5pt, `bmuxTextMuted`, lineLimit(nil), underline on hover

### Selection gesture
Use `simultaneousGesture` or a custom `ButtonStyle` so taps on resource links fire their own actions and do not trigger card selection.

### States
| State | Fill | Border |
|---|---|---|
| Unselected | bmuxCard | bmuxCardBorder |
| Selected | bmuxCardSelected | bmuxCardSelectedBorder |
| Hover (unselected) | slightly lighter, ~#212121 | bmuxCardBorder |

---

## BmuxContentPane

```swift
VStack(alignment: .leading, spacing: 0) {
    BmuxWorkspaceHeader()
    BmuxPrimaryTabs()
    // active tab view
}
.padding(.horizontal, BmuxSpacing.contentPaddingH)
.padding(.vertical, BmuxSpacing.contentPaddingV)
```

---

## BmuxWorkspaceHeader

- Eyebrow: "repo / Owner", 12pt, `bmuxTextMuted`
- Title: 26pt bold, `bmuxTextPrimary`, lineLimit(nil)
- Subtitle: 13.5pt, `bmuxTextTertiary`
- VStack spacing: eyebrow→title 4pt, title→subtitle 4pt
- Bottom margin before tabs: 16pt

---

## BmuxPrimaryTabs

- HStack(alignment: .bottom, spacing: 0) with 24pt gap between tabs
- Each tab: text-only, 13.5pt
  - Active: weight .medium, `bmuxTextPrimary`
  - Inactive: weight .regular, `bmuxTextMuted`
- Active indicator: Rectangle(), height 2pt, `bmuxTabUnderline`, width = label width, bottom-aligned
- Full-width 1pt bottom border: `bmuxSeparatorSubtle` (separate from the indicator)
- Bottom margin to content: 20pt

---

## BmuxSessionView

### BmuxSecondaryTabs
- HStack(spacing: 4)
- Active: `bmuxPillActive` background, 6pt radius, 13pt medium, `bmuxTextSecondary`
- Inactive: no background, 13pt, `bmuxTextMuted`
- Padding: H 12pt, V 4pt on pill
- Count suffix: same text, `bmuxTextMuted`

### BmuxCurrentTurn
```swift
HStack(spacing: 0) {
    Rectangle()
        .fill(Color.bmuxTurnAccent)
        .frame(width: BmuxSpacing.turnBorderWidth)
    VStack(alignment: .leading, spacing: 0) {
        HStack {
            Text("CURRENT TURN")  // turnEyebrow, uppercase, tracking 1.4
            Spacer()
            Text("Codex · 28m 36s")  // 12pt, bmuxTextMuted
        }
        Text(headline)  // turnHeadline
        Text(body)      // turnBody, bmuxTextTertiary, lineSpacing(...)
        HStack(spacing: 6) {
            Text("Agent-reported")  // 12pt, bmuxTextMuted
            Button("View source") { }  // bmuxLinkGreen, underline
        }
    }
    .padding(.leading, BmuxSpacing.turnPaddingLeft)
}
```
- Not a generic card — do not add a border or background
- Eyebrow → headline: 4pt
- Headline → body: 6pt
- Body → source: 8pt

### BmuxOverlapNotice
```swift
HStack(spacing: 8) {
    Image(systemName: "square.on.square")  // 14pt, bmuxAmberText
    Text(message)  // 13pt, bmuxAmberText
    Spacer()
    Button("Inspect overlap") { }  // 13pt, bmuxAmberText, underline
}
.padding(.horizontal, 12)
.padding(.vertical, 10)
.background(Color.bmuxAmberFill)
.clipShape(RoundedRectangle(cornerRadius: BmuxRadius.amberNotice))
.overlay(RoundedRectangle(cornerRadius: BmuxRadius.amberNotice).stroke(Color.bmuxAmberBorder, lineWidth: 1))
```

### BmuxDisclosureRow
- HStack: leading icon (15pt, `bmuxTextMuted`) + label (13.5pt, `bmuxTextSecondary`) + meta (12.5pt, `bmuxTextMuted`) + Spacer + plus icon
- Padding V: 14pt
- Separator: 1pt `bmuxSeparatorSubtle` between rows
- Expanded state: not shown in reference — implement as inferred collapsible detail

### BmuxPreviousTurns
- Section header: HStack("Previous turns" 14pt semibold + Spacer + "Newest first" 12pt `bmuxTextMuted`)
- Row: HStack(label VStack + Spacer + tokens/expand)
  - Label: 13.5pt `bmuxTextSecondary`
  - Meta: 11.5pt `bmuxTextMuted`, top-padding 2pt
  - "Tokens —": 12pt `bmuxTextMuted`; show null as "—"
  - Plus control: 12pt `bmuxTextMuted`
- Row padding V: 12pt
- Row separator: 1pt `#1e1e1e`

---

## BmuxTerminalView

### Layout
```swift
VStack(spacing: 0) {
    ScrollView {
        VStack(alignment: .leading, spacing: 16) {
            BmuxUserMessage(...)
            BmuxAssistantMessage(...)
        }
    }
    BmuxFollowUpComposer(...)
}
```

Scroll ownership: content scrolls; composer is sticky at bottom. (Inferred — not confirmed by screenshot crops.)

### BmuxUserMessage
```swift
VStack(alignment: .leading, spacing: 8) {
    HStack {
        Text("You").font(BmuxFont.authorLabel).foregroundColor(.bmuxTextSecondary)
        Spacer()
        Text("5:02 PM").font(BmuxFont.conversationTime).foregroundColor(.bmuxTextMuted)
    }
    Text(body).font(BmuxFont.conversationBody).foregroundColor(.bmuxTextSecondary)
}
.padding(16)
.background(Color.bmuxUserMessage)
.clipShape(RoundedRectangle(cornerRadius: BmuxRadius.card))
```

### BmuxAssistantMessage
```swift
VStack(alignment: .leading, spacing: 12) {
    HStack(spacing: 6) {
        Image(systemName: "sparkle").font(.system(size: 13)).foregroundColor(.bmuxTextTertiary)
        Text("Codex").font(BmuxFont.authorLabel).foregroundColor(.bmuxTextSecondary)
    }
    Text(leadBody).font(BmuxFont.conversationBody).foregroundColor(.bmuxTextTertiary)
    ForEach(actions) { BmuxActionRow($0) }
    ForEach(followUpParagraphs, id: \.self) {
        Text($0).font(BmuxFont.conversationBody).foregroundColor(.bmuxTextTertiary)
    }
    BmuxRunStatus(elapsed: "28m 36s")
}
```

### BmuxActionRow
```swift
HStack {
    Image(systemName: "checkmark").font(.system(size: 12)).foregroundColor(.bmuxAccentGreen)
    Text(label).font(BmuxFont.actionRowLabel).foregroundColor(.bmuxTextTertiary)
    Spacer()
    Text(status).font(BmuxFont.actionRowStatus).foregroundColor(.bmuxTextMuted)
}
.padding(.horizontal, BmuxSpacing.actionRowPaddingH)
.padding(.vertical, BmuxSpacing.actionRowPaddingV)
.background(Color.bmuxActionRow)
.clipShape(RoundedRectangle(cornerRadius: BmuxRadius.actionRow))
.overlay(RoundedRectangle(cornerRadius: BmuxRadius.actionRow).stroke(Color.bmuxActionRowBorder, lineWidth: 1))
```

### BmuxRunStatus
```swift
HStack {
    Image(systemName: "clock").font(.system(size: 13)).foregroundColor(.bmuxTextMuted)
    Text("Working · \(elapsed)").font(BmuxFont.workingStatus).foregroundColor(.bmuxTextMuted)
    Spacer()
    Button("Stop") { }.font(BmuxFont.workingStatus).foregroundColor(.bmuxTextTertiary)
        .underline()
}
```

### BmuxFollowUpComposer
```swift
VStack(spacing: 0) {
    VStack(alignment: .leading, spacing: 6) {
        Text("Follow up with Codex").font(BmuxFont.composerMeta).foregroundColor(.bmuxTextDisabled)
    }
    .padding(.horizontal, BmuxSpacing.composerPaddingH)
    .padding(.top, BmuxSpacing.composerPaddingV)
    .padding(.bottom, 4)

    Divider().background(Color.bmuxComposerDivider)  // #222222

    TextEditor(text: $composerText)
        .font(BmuxFont.composerInput)
        .foregroundColor(.bmuxTextTertiary)
        .frame(minHeight: 72)
        .padding(.horizontal, BmuxSpacing.composerPaddingH)
        .padding(.vertical, 8)
        .scrollContentBackground(.hidden)

    HStack {
        Text("Codex · medium effort").font(BmuxFont.composerMeta).foregroundColor(.bmuxTextMuted)
        Spacer()
        Button("Queue message ↑") { }
            .font(BmuxFont.queueButton)
            .foregroundColor(.bmuxQueueText)
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(Color.bmuxQueueFill)
            .clipShape(RoundedRectangle(cornerRadius: BmuxRadius.queueButton))
            .overlay(RoundedRectangle(cornerRadius: BmuxRadius.queueButton).stroke(Color.bmuxQueueBorder, lineWidth: 1))
    }
    .padding(.horizontal, BmuxSpacing.composerPaddingH)
    .padding(.bottom, BmuxSpacing.composerPaddingV)
}
.background(Color.bmuxComposer)
.clipShape(RoundedRectangle(cornerRadius: BmuxRadius.composer))
.overlay(RoundedRectangle(cornerRadius: BmuxRadius.composer).stroke(Color.bmuxComposerBorder, lineWidth: 1))
```

### BmuxTerminalFooter
```swift
HStack {
    Text("~/repos/companycam-mobile").font(BmuxFont.footer).foregroundColor(.bmuxTextDisabled)
    Spacer()
    Button("Session overview ↗") { }.font(BmuxFont.footer).foregroundColor(.bmuxTextMuted).underline()
}
.padding(.top, 8)
```

---

## Accessibility

- All interactive controls: `.accessibilityLabel(...)` with descriptive string
- Card selection: `.accessibilityAddTraits(.isSelected)` when selected
- Resource links within cards: individual `.accessibilityElement(children: .contain)` so they receive independent focus
- Tab bar: `.accessibilityAddTraits(.isSelected)` on active tab button
- Composer: `.accessibilityLabel("Follow up with Codex")`
- Stop button: `.accessibilityLabel("Stop agent")`
- Focus order follows visual order (top-to-bottom, rail before content)

---

## Residual unknowns

| Item | Status |
|---|---|
| Retina scale of reference screenshots | Assumed 1x; verify before finalizing pt values |
| Exact font PostScript name | Visual match only — SF Pro substitution recommended |
| Disclosure row expanded state | Inferred; not in reference |
| Header/composer sticky behavior | Inferred from layout; not confirmed by screenshot |
| Token counts in previous turns | Null in fixtures; confirm API field |
| Native tab content | Not shown; implement as stub |
